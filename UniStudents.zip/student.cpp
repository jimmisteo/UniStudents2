#include "student.h"

student::student() {
	first_name = "NONE";
	last_name = "NONE";
	email = "NONE";
	password = "NONE";
	ac_id = "NONE";
	am = "NONE";
	birth_date = "00/00/0000";
	semester = 0;
	ects = 0;
	remember = false;
}
student::student(std::string f_name, std::string l_name, std::string ac_email,std::string pass, std::string id, std::string ar_m, std::string b_date, int sem, int ect,bool rem) {

	first_name = f_name;
	last_name = l_name;
	email = ac_email;
	password = pass;
	ac_id = id;
	am = ar_m;
	birth_date = b_date;
	semester = sem;
	ects = ect;
	remember = rem;

}
