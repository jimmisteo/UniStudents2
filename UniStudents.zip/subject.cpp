#include "subject.h"
#include <ctime>

 subject::subject(std::string s_name,int s_sem){
	 name = s_name;
	 s_semester = s_sem;
	 srand(time(NULL));
	 mon = rand() % 3 + 4;
	 grade = rand() % 10;
	}
