#pragma once
#include "student.h"

class subject : public student
{
public:
	std::string name;
	int mon;
	int s_semester;
	float grade;
	subject(std::string s_name, int s_sem);
};

