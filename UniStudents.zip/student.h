#pragma once
#include <string>
class student
{
public:
	std::string first_name;
	std::string last_name;
	std::string email;
	std::string password;
	std::string ac_id;
	std::string am;
	std::string birth_date;
	bool remember;
	
	int semester;
	int ects;
	student();
	student(std::string f_name, std::string l_name, std::string ac_email,std::string pass, std::string id, std::string ar_m, std::string b_date, int sem, int ect,bool rem);
	
};

